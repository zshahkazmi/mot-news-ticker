<?php
/*
Plugin Name: MOT News Ticker
Description: Displays a dynamic news ticker with the latest blog posts about MOT and cars.
Version: 1.0
Author: CheckMyMOT Team
*/

add_shortcode('mot_news_ticker', function () {
  ob_start(); ?>
  <style>
    .mot-news-ticker-wrapper {
      display: flex;
      align-items: center;
      background: #111;
      color: #fff;
      overflow: hidden;
      font-family: 'Segoe UI', sans-serif;
      padding: 10px 0;
      border-top: 2px solid #007bff;
      border-bottom: 2px solid #007bff;
    }
    .mot-news-label {
      background: #007bff;
      color: #fff;
      padding: 10px 15px;
      font-weight: bold;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .mot-news-ticker {
      flex-grow: 1;
      overflow-x: auto;
      overflow-y: hidden;
      position: relative;
      white-space: nowrap;
      padding: 0 20px;
      cursor: grab;
      scroll-behavior: smooth;
    }
    .mot-news-ticker ul {
      display: inline-flex;
      gap: 50px;
      margin: 0;
      padding: 0;
      list-style: none;
      animation: motScroll 40s linear infinite;
    }
    .mot-news-ticker ul li {
      white-space: nowrap;
    }
    .mot-news-ticker a {
      color: #fff;
      font-size: 16px;
      text-decoration: none;
      transition: color 0.3s;
    }
    .mot-news-ticker a:hover {
      color: #ffc107;
      text-decoration: underline;
    }
    @keyframes motScroll {
      0% { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }
  </style>

  <div class="mot-news-ticker-wrapper">
    <div class="mot-news-label">🚗 MOT & Car News</div>
    <div class="mot-news-ticker drag-scroll" id="motTicker">
      <ul>
        <?php
          $recent_posts = wp_get_recent_posts([
            'numberposts' => 10,
            'post_status' => 'publish'
          ]);
          foreach ($recent_posts as $post) {
            $title = esc_html($post['post_title']);
            $url = get_permalink($post['ID']);
            echo "<li><a href='{$url}'>{$title}</a></li>";
          }
        ?>
      </ul>
    </div>
  </div>
  <?php
  return ob_get_clean();
});
