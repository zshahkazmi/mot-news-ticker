# MOT News Ticker Plugin

This is a custom WordPress plugin that displays a scrolling news ticker with your latest blog posts.

## Features
- Automatically pulls the latest 10 published blog posts
- Smooth animated horizontal ticker
- Fully responsive and lightweight
- Uses shortcode: [mot_news_ticker]

## Installation
1. Download or clone this repository.
2. Zip the folder (mot-news-ticker).
3. Go to your WordPress dashboard → Plugins → Add New → Upload Plugin.
4. Upload the ZIP file and activate the plugin.
5. Use the shortcode [mot_news_ticker] anywhere on your site.

## License
MIT
